﻿using AppCore.Interfaces;
using Domain.Entities;
using Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppCore.Services
{
    public class EstudianteServices : Service<Estudiante>, IEstudainteServices
    {
        IEstudianteModel model;

        public EstudianteServices(IEstudianteModel model) : base(model)
        {
            this.model = model;
        }
        public Estudiante FindById(int id)
        {
            return model.FindById(id);
        }
    }
}
