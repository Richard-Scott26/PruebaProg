﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
    public class Estudiante
    {
        public int id { get; set; }
        public String Nombres { get; set; }
        public String Apellidos { get; set; }
        public String Carnet { get; set; }
        public String Telefono { get; set; }
        public String Direccion { get; set; }
        public String Correo { get; set; }
        public double Matematica { get; set; }
        public double Contabilidad { get; set; }
        public double Programacion{ get; set; }
        public double Estadistica { get; set; }

        public virtual ICollection<Estudiante> Estudiantes { get; set; }
    }
}
