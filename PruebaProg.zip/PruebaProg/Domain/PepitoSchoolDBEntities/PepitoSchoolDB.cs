﻿using Domain.Entities;
using Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.PepitoSchoolDBEntities
{
    public partial class PepitoSchoolDB : DbContext, IEstudianteDBContext
    {
        public PepitoSchoolDB() { }

        public PepitoSchoolDB(DbContextOptions<PepitoSchoolDB> options) : base(options) { }

        public virtual DbSet<Estudiante> Estudiante { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=JADPA29\\SQLSERVER2019;Initial Catalog=PepitoSchool;user=sa;password=123456");
            }
        }
    }
