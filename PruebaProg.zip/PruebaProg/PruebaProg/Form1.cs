﻿using Domain.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PruebaProg
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Estudiante estudiante = new Estudiante()
            {
                Nombres = txtNombres.Text,
                Apellidos = txtApellidos.Text,
                Carnet = txtCarnet.Text,
                Correo = txtCorreo.Text,
                Direccion = txtDireccion.Text,
                Telefono = txtTelefono.Text,
                Matematica = double.Parse(txtMatematica.Text),
                Contabilidad = double.Parse(txtContabilidad.Text),
                Programacion = double.Parse(txtProgramacion.Text),
                Estadistica = double.Parse(txtEstadistica.Text)
            };


        }
    }
}
