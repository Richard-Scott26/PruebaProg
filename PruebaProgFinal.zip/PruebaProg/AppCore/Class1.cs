﻿using System;

namespace AppCore
{
    public class Class1
    {
    }
}
