﻿using System;

namespace Infraestructura
{
    public class Class1
    {
    }
}
