using AppCore.Interfaces;
using AppCore.Services;
using Domain.EstudianteDBEntities;
using Domain.Interfaces;
using Infraestructura.Repository;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PruebaProg
{
    static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            

            //Configuration = new ConfigurationBuilder().AddJsonFile("appSettings.json")
            //    .AddEnvironmentVariables().Build();

            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var services = new ServiceCollection();

            services.AddDbContext<PepitoSchoolContext>(options =>
            {
                //options.UseSqlServer(Configuration.GetConnectionString("Default"));
            });
            //services.AddScoped<IEstudianteDBContext, PepitoSchoolContext>();
            services.AddScoped<IEstudianteModel, EFEstudianteRepository>();
            services.AddScoped<IEstudianteServices, EstudianteServices>();
            services.AddScoped<Form1>();

            using (var serviceScope = services.BuildServiceProvider())
            {
                var main = serviceScope.GetRequiredService<Form1>();
                Application.Run(main);
            }
        }
    }
}
